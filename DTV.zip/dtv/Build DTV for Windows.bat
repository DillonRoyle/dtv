@echo off
title Building DTV
cd /d "%~dp0"
echo.
echo  ===============================
echo    DTV - building the Windows app
echo  ===============================
echo.
where npm >nul 2>nul
if errorlevel 1 (
  echo  Node.js isn't installed yet.
  echo  1. Download the LTS version from https://nodejs.org
  echo  2. Install it with the default options
  echo  3. Double-click this file again
  echo.
  start https://nodejs.org
  pause
  exit /b 1
)
echo  Step 1 of 2: downloading what DTV needs (first time only, a few minutes)...
call npm install
if errorlevel 1 (
  echo.
  echo  The download failed. Check your internet connection and try again.
  pause
  exit /b 1
)
echo.
echo  Step 2 of 2: building DTV...
call npm run dist:win
if errorlevel 1 (
  echo.
  echo  The build failed. Scroll up to see the error.
  pause
  exit /b 1
)
echo.
echo  Done! Your installer and portable app are in the "dist" folder.
start "" "%~dp0dist"
pause
